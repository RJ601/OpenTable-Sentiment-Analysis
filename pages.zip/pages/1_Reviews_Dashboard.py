# MODULE 3 - GUI DEVELOPMENT

from util import scrape_reviews, llm_analysis, toJson, system_message
import streamlit as st
import numpy as np
import pandas as pd

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
import json
from nltk.tokenize import sent_tokenize

from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

import matplotlib.pyplot as plt

# Title and Description
st.title("Reviews")

restaurant = ""
url = ""
url = st.text_input("Enter URL of the restaurant: ")
print("URL: ", url)

if st.button("Submit"):
    print("URL: ", url)
    restaurant = scrape_reviews(url)
    file_path = (f"{restaurant}.csv")
    analysis = llm_analysis(file_path, system_message)
    print("Analysis:", analysis)
    toJson(analysis, restaurant)
else:
    st.stop()

print("URL: ", url)

driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

driver.get(url)

# name of restaurant
restaurant = (driver.find_element(By.TAG_NAME, 'h1')).text

# would display in sidebar
details = driver.find_elements(By.CSS_SELECTOR, ".jlOtKZTqWqc- li .ugL-ExXtGrk-")

# build a dashboard using data from the json file created 
with open(f"Review_Analysis_{restaurant}.json", 'r') as file:
    reviews = json.load(file)

st.title(f'{restaurant}')

# dashboard for filtering reviews inserted here
st.markdown("""
    <style>
    .stRadio>div>label {
        background-color: #f0f0f0;
        padding: 10px;
        border-radius: 5px;
        display: inline-block;
        margin-right: 10px;
    }
    .stRadio>div>label:hover {
        background-color: #e0e0e0;
    }
    </style>
""", unsafe_allow_html=True)
option = st.multiselect("Filter: ", options = ['All', '5-star', '4-star', '3-star', '2-star', '1-star'], default = ['All'])

sidebar_section = st.sidebar.container()
with sidebar_section:
    st.header(f"{restaurant}")
    st.divider()

    for d in details:
        heading = d.find_element(By.TAG_NAME, "span").text
        text = d.find_element(By.TAG_NAME, "div").text
        if heading: 
            st.text(f"{heading}: {text}")

# loop through the list and display reviewer, date, rating and comment
for review in reviews:
    display = False
    if ('All' in option):
        display = True
    else:
        if f"{int(review['Rating'])}-star" in option:
            display = True

    if display:
        cols = st.columns([1, 1, 1])
        cols[0].markdown(f"<span style='font-size:20px;'>{review["Reviewer"]}</span>", unsafe_allow_html=True)
        cols[2].markdown(f"<span style='font-size:12px;'>{review["Date"]}</span>", unsafe_allow_html=True)

        cols = st.columns([0.1,0.1,0.1,0.1,0.1,2,0.5])
        rating = int(review['Rating'])
        for count in range(rating):
            cols[count].markdown(f"<span style='font-size:14px;'>⭐</span>", unsafe_allow_html=True)
        cols[6].markdown(f"<span style='font-size:14px;'>{rating}</span>", unsafe_allow_html=True)

        Review = sent_tokenize(review["Review"])
        Food_Comment = sent_tokenize(review['Food']['Comment'])
        Staff_Comment = sent_tokenize(review['Staff']['Comment'])

        temp_store = ""
        for sentence in Review:
            food = False
            staff = False
            # if present in food - change to blue
            for f in Food_Comment:
                if f in sentence:
                    temp_store += f"<span style='color:crimson;font-size: 14px;'> {sentence}</span>"
                    food = True

            # if present in staff - change to pink
            for s in Staff_Comment:
                if s in sentence:
                    temp_store += f"<span style='color:purple;font-size: 14px;'> {sentence}</span>"
                    staff = True

            # else - print as it is
            if not food and not staff:
                temp_store += f"<span style='font-size: 14px;'> {sentence}</span>"

        st.markdown(temp_store, unsafe_allow_html=True)
        temp_store = ""
        st.divider()

# FUTURE SUGGESTION
# side bar for color coding: positive, negative, neutral food reviews, positive, negative, neutral staff reviews