# MODULE 4 - COMPETITOR ANALYSIS

from util import scrape_reviews
import streamlit as st
import numpy as np
import pandas as pd
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException

from selenium.webdriver.chrome.service import Service as ChromeService
from webdriver_manager.chrome import ChromeDriverManager

import matplotlib.pyplot as plt

driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()))

# Title and Description
st.title("Competitor Analysis")

urls = []
for count in range(2):
    u = st.text_input("Enter URL of the restaurant: ", key=count)
    urls.append(u)

# save urls in a txt file for later reference
if st.button("Submit"):
    print(urls)
else:
    st.stop()

# scrape for both restaurants - same dates
months = ["January", "February", "March", "April", "May", "June", 
    "July", "August", "September", "October", "November", "December"]
pages = [5, 5] # default page numbers to start scrapping
index1 = 0
index2 = 0

# bringing pages to same dates

driver.get(f"{urls[0]}&page=5")
date1 = (driver.find_element(By.CSS_SELECTOR, ".iLkEeQbexGs-")).text
pages[0] = driver.find_element(By.CSS_SELECTOR, ".g-dxt-fQ2ZU-.C7Tp-bANpE4-.qfZDsxm8aWs-").text
for idx, month in enumerate(months):
    print(month)
    print(date1)
    print(pages[0])
    if month in date1:
        index1 = idx
        m1 = month
        break

driver.get(f"{urls[1]}&page=5")
#driver.switch_to.window(driver.window_handles[1]) 
date2 = driver.find_element(By.CSS_SELECTOR, ".iLkEeQbexGs-").text
pages[1] = driver.find_element(By.CSS_SELECTOR, ".g-dxt-fQ2ZU-.C7Tp-bANpE4-.qfZDsxm8aWs-").text
for idx, month in enumerate(months):
    print(month)
    print(date2)
    print(pages[1])
    if month in date2:
        index2 = idx
        m2 = month
        break

print(index1, index2)

count = 6
if index1 < index2: # restaurant 1 starts from earlier date - bring restaurant 2 to that date
    while m1 not in date2:
        driver.get(f"{urls[1]}&page={count}")
        #driver.switch_to.window(driver.window_handles[1]) 
        date2 = driver.find_element(By.CSS_SELECTOR, ".iLkEeQbexGs-").text
        if m1 in date2:
            print(m1, date2)
            pages[1] = driver.find_element(By.CSS_SELECTOR, ".g-dxt-fQ2ZU-.C7Tp-bANpE4-.qfZDsxm8aWs-").text
        count += 1
    
elif index2 < index1:
    while m2 not in date1:
        driver.get(f"{urls[0]}&page={count}")
        #driver.switch_to.window(driver.window_handles[1]) 
        date1 = driver.find_element(By.CSS_SELECTOR, ".iLkEeQbexGs-").text
        if m2 in date1:
            print(m2, date1)
            pages[0] = driver.find_element(By.CSS_SELECTOR, ".g-dxt-fQ2ZU-.C7Tp-bANpE4-.qfZDsxm8aWs-").text
        count += 1

print(pages[0], pages[1])
driver.quit()

# save names in restaurants list and scrape reviews
restaurants = []
count = 0
for url in urls:
    restaurants.append((scrape_reviews(url, int(pages[count]), (int(pages[count])+6))))
    count += 1

plt.figure(figsize = (90, 50))

# create and format dataframes for both and plot them as line graphs
r = []
for restaurant in restaurants:
    r = pd.read_csv(f"{restaurant}.csv")

    # reformat the dataframe to contain only date and rating
    r = r.loc[:,['Rating', 'Date']]
    r = r.groupby('Date')['Rating'].mean()
    r = r.reset_index()

    # remove the unnecessary 'Dined on' part from the date
    split_from = (r['Date'][1].find("on ")) + 3
    for d in range(len(r['Date'])):
        r.iloc[d, 0] = r['Date'][d][split_from: ]

    day = []
    month= []
    year = []
    days = []
    # split the date into day, month, year
    for d in r['Date']:
        d = d.split(' ') #month, day, year
        year.append(d[2])

        d[1] = d[1].replace(',', "")
        day.append(d[1])
        
        for i, m in enumerate(months):
            if (m == d[0]):
                d[0] = i+1
                month.append(d[0])
                break
                
        days.append(int(d[1]) + d[0]*30) 

    r['Day'] = day
    r['Month'] = month
    r['year'] = year
    r['Days'] = days

    r = r.sort_values(by = "Days", ascending = False)

    # line plot after formatting
    plt.plot(r['Days'], r['Rating'], label = restaurant)


# display and save
plt.legend()
plt.savefig('Competitor_Analysis.jpg')
plt.show()
